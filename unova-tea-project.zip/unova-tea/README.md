# Unova Tea × Aulo Spa — Wholesale Portal

## 📁 Project Structure
```
unova-tea/
├── public/
│   ├── index.html          ← Client-facing order page
│   └── success.html        ← Shown after successful payment
├── netlify/
│   └── functions/
│       └── create-checkout.js  ← Talks to Stripe (runs on server)
├── netlify.toml            ← Netlify configuration
├── package.json            ← Stripe dependency
└── README.md               ← This file
```

---

## 🚀 How to Deploy (Step by Step)

### Step 1 — Create a GitHub account
1. Go to github.com → Sign up (free)

### Step 2 — Create a new repository
1. Click the **+** in the top right → **New repository**
2. Name it `unova-tea` → Click **Create repository**
3. Upload all these files (drag and drop the whole folder)

### Step 3 — Create a Netlify account
1. Go to netlify.com → Sign up with your GitHub account

### Step 4 — Connect your repo to Netlify
1. In Netlify → **Add new site** → **Import an existing project**
2. Choose **GitHub** → Select `unova-tea`
3. Build settings:
   - Build command: `npm install`
   - Publish directory: `public`
4. Click **Deploy site**

### Step 5 — Add your Stripe keys (CRITICAL)
1. Go to **stripe.com** → Create a free account
2. In Stripe dashboard → **Developers** → **API Keys**
3. Copy your **Publishable key** and **Secret key**
4. In Netlify → **Site settings** → **Environment variables** → Add:
   - `STRIPE_SECRET_KEY` = `sk_live_xxxxxxxxxxxx`  ← your secret key
5. **Redeploy** the site after adding the key

### Step 6 — You're live! 🎉
- Netlify gives you a URL like `https://unova-tea-aulo.netlify.app`
- Share that link with Aulo Spa
- Payments go straight to your Stripe account
- You'll get email notifications for every new subscription

---

## 💰 How Payments Work
- Client builds their order → clicks **Subscribe Monthly**
- Enters their name + email → clicks **Go to Secure Checkout**
- Your Netlify function creates a Stripe session
- Client is redirected to Stripe's hosted checkout page (100% secure)
- After payment, Stripe redirects them to your success page
- Money lands in your Stripe account (2.9% + 30¢ per transaction)
- You can manage all subscriptions at dashboard.stripe.com

---

## 🧾 Pricing Logic
- Loose leaf teas: **$0.48/g**
- Matcha: **$0.72/g**
- Minimum order: **$100**
- Free delivery: Growth ($180+) and Premium plans, or any order ≥ $180
- Standard shipping: **$20** (Starter and Core plans)

---

## ✏️ How to Edit the Client Page
Open `public/index.html` in any text editor.
- Change client name/location: search for "Aulo Spa" and "Newark, NJ"
- Change tea names: find the `TEAS` array in the `<script>` section
- Change pricing: find `LOOSE_RATE` and `MATCHA_RATE` constants
- Change minimum order: find `MIN_ORDER` constant

After editing, re-upload to GitHub → Netlify auto-redeploys in ~30 seconds.

---

## 📧 Questions?
unovatea@gmail.com
